// pages/dashboard-teste.jsx (Next.js) ou src/Dashboard.jsx (CRA)
// Dependências: npm i react chart.js
// Observação: uso direto do Chart.js (sem react-chartjs-2) + ResizeObserver para evitar charts com largura 0.

import React, {useEffect, useLayoutEffect, useMemo, useRef, useState} from "react";
import Chart from "chart.js/auto";

// ---------- Hooks utilitários ----------
function useMeasure() {
  const ref = useRef(null);
  const [rect, setRect] = useState({ width: 0, height: 0 });
  useLayoutEffect(() => {
    if (!ref.current) return;
    const obs = new ResizeObserver((entries) => {
      const r = entries[0].contentRect;
      setRect({ width: r.width, height: r.height });
    });
    obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);
  return [ref, rect];
}

// ---------- Cores pastel ----------
const pastel = (a = 0.6) => `rgba(162,210,255,${a})`; // azul
const lavender = (a = 0.6) => `rgba(205,180,219,${a})`;

// ---------- Wrapper para Chart.js com sizing robusto ----------
function ChartCanvas({ type, data, options, height = 320, ariaLabel }) {
  const canvasRef = useRef(null);
  const [hostRef, rect] = useMeasure();
  const chartRef = useRef(null);

  // Garante largura/altura antes de instanciar o gráfico
  useEffect(() => {
    const el = canvasRef.current;
    if (!el || rect.width === 0) return;
    if (chartRef.current) chartRef.current.destroy();
    el.setAttribute("width", String(Math.max(280, rect.width)));
    el.setAttribute("height", String(height));
    chartRef.current = new Chart(el, {
      type,
      data,
      options: { responsive: false, maintainAspectRatio: false, ...options },
    });
    return () => chartRef.current?.destroy();
  }, [rect.width, height, type, data, options]);

  return (
    <div ref={hostRef} className="chartHost" aria-label={ariaLabel}>
      <canvas ref={canvasRef} />
      <style jsx>{`
        .chartHost{width:100%; height:${height}px}
        canvas{max-width:100%; display:block}
      `}</style>
    </div>
  );
}

// ---------- Componentes UI ----------
function Icon({ path }) {
  return (
    <svg className="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor">
      <path d={path} />
      <style jsx>{`
        .icon{width:18px;height:18px;flex:0 0 18px;display:inline-block}
      `}</style>
    </svg>
  );
}

// Ícones compostos para os cards de módulo (múltiplos paths)
function IconMulti({ paths = [], size = 22, strokeWidth = 2 }) {
  return (
    <svg
      className="micon"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths.map((d, i) => (<path key={i} d={d} />))}
      <style jsx>{`
        .micon{flex:0 0 auto;display:inline-block}
      `}</style>
    </svg>
  );
}

function Sidebar(){
  return (
    <aside className="sidebar">
      <div className="brand"><div className="logo">TM</div> TeleMed</div>
      <div className="section-title">Menu</div>
      <nav className="nav">
        <a className="active" href="#"><Icon path="M3 12l9-9 9 9 M9 21V9h6v12"/> Dashboard</a>
        <a href="#"><Icon path="M3 21v-1a5 5 0 0 1 5-5a5 5 0 0 1 5 5v1 M12 21v-1a5 5 0 0 1 5-5a5 5 0 0 1 5 5v1 M8 11a3 3 0 1 0 0-6 a3 3 0 0 0 0 6 M16 11a3 3 0 1 0 0-6 a3 3 0 0 0 0 6"/> Pacientes</a>
        <a href="#"><Icon path="M12 12c2.2 0 4-1.8 4-4S14.2 4 12 4 8 5.8 8 8s1.8 4 4 4z M20 20a8 8 0 10-16 0"/> Médicos</a>
        <a href="#analytics"><Icon path="M4 19V5 M10 19V9 M16 19V13 M22 19V3"/> Analytics</a>
        <a href="#prontuario"><Icon path="M4 6h12 M4 12h12 M4 18h12 M18 6h2v12h-2"/> Prontuário</a>
        <div className="section-title">Ações Rápidas</div>
        <div className="quick-actions">
          <button className="btn primary">Nova Consulta</button>
          <button className="btn secondary">Novo Paciente</button>
          <button className="btn secondary">Teleconsulta</button>
          <button className="btn secondary">Prescrição</button>
        </div>
      </nav>
      <style jsx>{styles}</style>
    </aside>
  )
}

function Topbar(){
  return (
    <div className="topbar">
      <div className="search">
        <svg className="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.35-4.35"/></svg>
        <input placeholder="Buscar por pacientes, exames, sintomas…" />
      </div>
      <span className="chip">Período: Este ano</span>
      <span className="chip">Departamento: Todos</span>
      <span className="chip">Convênio: Todos</span>
      <style jsx>{styles}</style>
    </div>
  );
}

function KpiCard({title, value, delta, deltaType="neutral", data, colorFn}){
  const chartData = useMemo(()=>({
    labels: data.map((_,i)=>i+1),
    datasets:[{ data, fill:true, tension:.35, borderColor:colorFn(.9), backgroundColor:colorFn(.28), pointRadius:0, borderWidth:2 }]
  }), [data, colorFn]);
  return (
    <div className="card">
      <h4 className="kpi-title">{title}</h4>
      <div className="kpi-value">{value} {delta && (<span className={`delta ${deltaType}`}>{delta}</span>)}</div>
      <ChartCanvas type="line" data={chartData} options={{ plugins:{legend:{display:false}}, scales:{x:{display:false}, y:{display:false}} }} height={44} ariaLabel={title} />
      <style jsx>{styles}</style>
    </div>
  );
}

function Heatmap(){
  const dias = 7, horas = 24;
  const cells = [];
  for(let d=0; d<dias; d++){
    for(let h=0; h<horas; h++){
      const v = Math.random();
      const alpha = 0.18 + v*0.62;
      cells.push(<div key={`${d}-${h}`} className="hm-cell" style={{background:`rgba(162,210,255,${alpha.toFixed(2)})`}} />);
    }
  }
  return (
    <>
      <div className="heatmap">{cells}</div>
      <div className="hm-legend"><span>Baixa</span><span className="hm-swatch" style={{background:"rgba(162,210,255,.18)"}}/><span className="hm-swatch" style={{background:"rgba(162,210,255,.35)"}}/><span className="hm-swatch" style={{background:"rgba(162,210,255,.55)"}}/><span className="hm-swatch" style={{background:"rgba(162,210,255,.75)"}}/><span>Alta</span></div>
      <style jsx>{styles}</style>
    </>
  );
}

function Timeline(){
  return (
    <ul className="timeline">
      <li><span className="dot"></span><div className="item"><strong>Consulta concluída</strong> – João Santos<br/><span className="meta">Hoje • 14:20</span></div></li>
      <li><span className="dot"></span><div className="item"><strong>Prescrição enviada</strong> – Amoxil 500mg<br/><span className="meta">Hoje • 13:55</span></div></li>
      <li><span className="dot"></span><div className="item"><strong>Exame recebido</strong> – Hemograma (PDF)<br/><span className="meta">Ontem • 18:10</span></div></li>
      <li><span className="dot"></span><div className="item"><strong>Anotação clínica</strong> – Dor torácica leve<br/><span className="meta">Ontem • 10:42</span></div></li>
      <style jsx>{styles}</style>
    </ul>
  );
}

// ---------- Página ----------
export default function DashboardTeleMed(){
  // Dados de exemplo
  const horas = Array.from({length:24}, (_,i)=>`${String(i).padStart(2,'0')}:00`);
  const valsHoras = [4,6,8,3,2,1,1,2,4,6,10,12,14,16,18,15,13,12,11,10,8,7,6,5];

  const barrasHoras = useMemo(()=>({ labels:horas, datasets:[{ data:valsHoras, backgroundColor: pastel(.7), borderColor:'#8AB8E6', borderWidth:1, borderRadius:8, barThickness:6 }] }),[]);
  const barrasOptions = useMemo(()=>({ indexAxis:'y', plugins:{legend:{display:false}}, scales:{ x:{ grid:{display:false}, ticks:{color:'#6B7280'} }, y:{ grid:{display:false}, ticks:{color:'#6B7280', autoSkip:false, maxTicksLimit:24} } } }),[]);

  const npsData = useMemo(()=>({ labels:['S1','S2','S3','S4','S5','S6','S7','S8'], datasets:[{ label:'NPS', data:[72,74,71,75,78,80,79,82], borderColor:pastel(.95), backgroundColor:pastel(.3), borderWidth:2, pointRadius:3, tension:.35, fill:true }] }),[]);
  const npsOptions = useMemo(()=>({ plugins:{legend:{display:false}}, scales:{ x:{grid:{display:false}}, y:{grid:{color:'rgba(0,0,0,0.04)'}, suggestedMin:60, suggestedMax:90} } }),[]);

  const filaData = useMemo(()=>({ labels:['Crítica','Alta','Média','Baixa'], datasets:[{ data:[8,14,9,5], backgroundColor:[lavender(.75), pastel(.75), pastel(.55), lavender(.45)], borderColor:'#8AB8E6', borderWidth:1, barThickness:6, borderRadius:8 }] }),[]);
  const filaOptions = useMemo(()=>({ indexAxis:'y', plugins:{legend:{display:false}}, scales:{ x:{grid:{display:false}}, y:{grid:{display:false}} } }),[]);

  return (
    <div className="page">
      <Sidebar/>
      <main>
        <Topbar/>

        {/* Módulos do Sistema – 5 cards no topo */}
        <section className="modules">
          <a className="module-card" href="#agenda" title="Agenda do Dia">
            <div className="module-icon">
              <IconMulti size={22} paths={["M3 7h18","M7 3v4","M17 3v4","M5 7h14v12H5z"]}/>
            </div>
            <div>
              <h4 className="module-title">Agenda do Dia</h4>
              <ul className="module-list">
                <li>Timeline interativa</li>
                <li>Agendamento rápido</li>
                <li>Notificações em tempo real</li>
              </ul>
            </div>
          </a>
          <a className="module-card" href="#pacientes" title="Gestão de Pacientes">
            <div className="module-icon">
              <IconMulti size={22} paths={[
                "M8 10a3 3 0 1 0 0-6 3 3 0 0 0 0 6",
                "M16 10a3 3 0 1 0 0-6 3 3 0 0 0 0 6",
                "M2 22v-1a5 5 0 0 1 5-5h0a5 5 0 0 1 5 5v1",
                "M12 22v-1a5 5 0 0 1 5-5h0a5 5 0 0 1 5 5v1"
              ]}/>
            </div>
            <div>
              <h4 className="module-title">Gestão de Pacientes</h4>
              <ul className="module-list">
                <li>Cadastro completo</li>
                <li>Histórico médico</li>
                <li>Relatórios personalizados</li>
              </ul>
            </div>
          </a>
          <a className="module-card" href="#medico" title="Perfil do Médico">
            <div className="module-icon">
              <IconMulti size={22} paths={[
                "M12 4a8 8 0 1 1 0 16 8 8 0 0 1 0-16z",
                "M12 8v8",
                "M8 12h8"
              ]}/>
            </div>
            <div>
              <h4 className="module-title">Perfil do Médico</h4>
              <ul className="module-list">
                <li>Dados profissionais</li>
                <li>Certificações</li>
                <li>Horários de trabalho</li>
              </ul>
            </div>
          </a>
          <a className="module-card" href="#config" title="Configurações">
            <div className="module-icon">
              <IconMulti size={22} paths={[
                "M4 6h16",
                "M4 12h16",
                "M4 18h16",
                "M8 4v4",
                "M12 10v4",
                "M16 16v4"
              ]}/>
            </div>
            <div>
              <h4 className="module-title">Configurações</h4>
              <ul className="module-list">
                <li>Integrações</li>
                <li>Backup e segurança</li>
                <li>Logs do sistema</li>
              </ul>
            </div>
          </a>
          <a className="module-card" href="#demo" title="Demo Responsivo">
            <div className="module-icon">
              <IconMulti size={22} paths={[
                "M7 2h10a2 2 0 0 1 2 2v16a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2z",
                "M12 18h.01"
              ]}/>
            </div>
            <div>
              <h4 className="module-title">Demo Responsivo</h4>
              <ul className="module-list">
                <li>Simulador de dispositivos</li>
                <li>Performance otimizada</li>
                <li>Interface adaptativa</li>
              </ul>
            </div>
          </a>
        </section>

        <section className="kpis">
          <KpiCard title="Pacientes Cadastrados" value={847} delta="+3% vs. semana passada" deltaType="up" data={[10,12,11,13,14,15,14,16,18,17,19,21]} colorFn={pastel}/>
          <KpiCard title="Consultas Hoje" value={12} delta="-7% vs. ontem" deltaType="down" data={[9,8,10,7,8,6,7,6,7,5,6,5]} colorFn={lavender}/>
          <KpiCard title="Prescrições Pendentes" value={5} delta="meta: ≤ 4" data={[6,5,6,7,5,6,4,5,5,4,5,5]} colorFn={pastel}/>
          <KpiCard title="Avaliação Média" value={4.0} delta="+0.2 vs. mês anterior" deltaType="up" data={[3.6,3.7,3.8,3.7,3.9,4.0,3.9,4.1,4.0,4.2,4.1,4.0]} colorFn={lavender}/>
        </section>

        <section id="analytics" className="grid-2">
          <div className="card">
            <h3>Atendimentos por Hora</h3>
            <p className="meta">Distribuição de atendimentos ao longo do dia</p>
            <ChartCanvas type="bar" data={barrasHoras} options={barrasOptions} ariaLabel="Barras horizontais – Atendimentos por Hora" />
          </div>
          <div className="card">
            <h3>Horários de Pico (Heatmap)</h3>
            <p className="meta">Intensidade por dia x hora</p>
            <Heatmap/>
          </div>
        </section>

        <section id="prontuario" className="grid-3">
          <div className="card">
            <h3>Timeline do Prontuário</h3>
            <p className="meta">Eventos clínicos recentes</p>
            <Timeline/>
          </div>
          <div className="card">
            <h3>Satisfação do Paciente</h3>
            <p className="meta">NPS por semana</p>
            <ChartCanvas type="line" data={npsData} options={npsOptions} ariaLabel="Linha – NPS" />
          </div>
          <div className="card">
            <h3>Fila por Prioridade</h3>
            <p className="meta">Barras finas, horizontais</p>
            <ChartCanvas type="bar" data={filaData} options={filaOptions} ariaLabel="Fila por prioridade" />
          </div>
        </section>

        <section className="card">
          <div className="quick-actions">
            <button className="btn primary">Agendar Consulta</button>
            <button className="btn secondary">Ver Relatórios</button>
            <button className="btn secondary">Importar Exames</button>
            <button className="btn secondary">Abrir Teleconsulta</button>
          </div>
        </section>
      </main>

      <style jsx global>{globalStyles}</style>
      <style jsx>{styles}</style>
    </div>
  );
}

// ---------- Estilos (styled-jsx) ----------
const globalStyles = `
  :root{
    --bg:#F6F8FB;
    --text:#1F2937; --muted:#6B7280; --card-bg:#FFFFFF;
    --shadow:0 2px 8px rgba(0,0,0,.05); --radius:12px; --pad:24px;
    --primary:#A2D2FF; --primary-600:#8AB8E6; --lavender:#CDB4DB; --border:1px solid rgba(0,0,0,.06);
  }
  *{box-sizing:border-box}
  html,body,#__next{height:100%}
  body{margin:0;font-family:Inter, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;color:var(--text);background:linear-gradient(180deg,#F9FBFF 0%, var(--bg) 100%)}
`;

const styles = `
  .page{display:flex}
  .sidebar{position:fixed;inset:0 auto 0 0;width:272px;background:#fff;box-shadow:var(--shadow);border-right:var(--border);padding:20px;display:flex;flex-direction:column;gap:16px}
  .brand{display:flex;align-items:center;gap:10px;font-weight:700;font-size:18px}
  .logo{width:34px;height:34px;display:grid;place-items:center;border-radius:10px;background:var(--primary);color:#0F172A;font-weight:700}
  .section-title{font-size:12px;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);margin:8px 0 4px}
  .nav{display:flex;flex-direction:column;gap:6px}
  .nav a{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;text-decoration:none;color:var(--text);transition:transform .15s ease, background .15s ease, opacity .15s ease}
  .nav a:hover{background:rgba(162,210,255,.18);opacity:.9}
  .nav a.active{background:rgba(162,210,255,.25);border:1px solid rgba(162,210,255,.6)}
  .quick-actions{display:flex;gap:12px;flex-wrap:wrap}

  main{margin-left:272px;padding:32px;display:flex;flex-direction:column;gap:24px}
  .topbar{display:flex;align-items:center;gap:16px;flex-wrap:wrap}
  .search{flex:1;min-width:260px;display:flex;align-items:center;gap:10px;background:#fff;border-radius:12px;padding:10px 14px;box-shadow:var(--shadow);border:var(--border)}
  .search input{border:none;outline:none;width:100%;font-size:14px}
  .chip{background:#fff;padding:8px 12px;border-radius:999px;box-shadow:var(--shadow);border:var(--border);font-size:13px;color:#374151}

  /* === módulos no topo === */
  .modules{display:grid;grid-template-columns:repeat(5, minmax(220px,1fr));gap:24px}
  .module-card{display:flex;gap:12px;align-items:flex-start;text-decoration:none;color:var(--text);background:#fff;border-radius:var(--radius);box-shadow:var(--shadow);border:var(--border);padding:18px 18px;transition:transform .15s ease, box-shadow .15s ease, background .15s ease}
  .module-card:hover{transform:translateY(-2px);background:rgba(162,210,255,.06)}
  .module-icon{width:36px;height:36px;border-radius:10px;display:grid;place-items:center;background:rgba(162,210,255,.18)}
  .module-title{margin:0 0 6px;font-size:16px}
  .module-list{margin:0;padding-left:18px;color:var(--muted);font-size:13px}

  .kpis{display:grid;grid-template-columns:repeat(4, minmax(220px,1fr));gap:24px}
  .card{background:var(--card-bg);border-radius:var(--radius);box-shadow:var(--shadow);padding:var(--pad);transition:transform .16s ease, box-shadow .16s ease, opacity .16s ease}
  .card:hover{transform:translateY(-2px);opacity:.98}
  .kpi-title{font-size:13px;color:var(--muted);margin:0 0 8px}
  .kpi-value{font-size:32px;font-weight:700;letter-spacing:-.02em;display:flex;align-items:baseline;gap:10px}
  .delta{font-size:12px;padding:4px 8px;border-radius:999px;background:rgba(162,210,255,.22);border:1px solid rgba(162,210,255,.5)}
  .delta.up{background:rgba(34,197,94,.12);border-color:rgba(34,197,94,.4);color:#15803D}
  .delta.down{background:rgba(239,68,68,.10);border-color:rgba(239,68,68,.36);color:#B91C1C}

  .grid-2{display:grid;grid-template-columns:2fr 1.1fr;gap:24px}
  .grid-3{display:grid;grid-template-columns:1.3fr 1fr 1fr;gap:24px}
  .meta{margin:0 0 16px;color:var(--muted)}

  .btn{display:inline-flex;align-items:center;gap:8px;padding:10px 14px;border-radius:12px;border:1px solid transparent;cursor:pointer;font-weight:600;transition:opacity .15s ease,transform .15s ease}
  .btn:focus{outline:3px solid rgba(162,210,255,.35)}
  .btn:hover{opacity:.8}
  .btn.primary{background:var(--primary);border-color:var(--primary)}
  .btn.primary:hover{background:var(--primary-600)}
  .btn.secondary{background:transparent;border:1px solid var(--primary);color:#0F172A}

  /* Heatmap */
  .heatmap{display:grid;grid-template-columns:repeat(24, minmax(10px,1fr));gap:4px}
  .hm-cell{width:100%;aspect-ratio:1/1;border-radius:6px;border:1px solid rgba(162,210,255,.25)}
  .hm-legend{display:flex;align-items:center;gap:8px;color:var(--muted);font-size:12px;margin-top:12px}
  .hm-swatch{width:16px;height:16px;border-radius:4px;border:1px solid rgba(162,210,255,.45)}

  /* Timeline */
  .timeline{position:relative;padding-left:22px;margin:0;list-style:none}
  .timeline:before{content:"";position:absolute;left:8px;top:0;bottom:0;width:2px;background:linear-gradient(#E5E7EB,#D1D5DB)}
  .timeline li{position:relative;padding:10px 0}
  .timeline li .dot{position:absolute;left:2px;top:16px;width:12px;height:12px;border-radius:999px;background:var(--primary);box-shadow:0 0 0 3px rgba(162,210,255,.25)}
  .timeline li .item{background:#fff;border-radius:10px;box-shadow:var(--shadow);border:var(--border);padding:12px 14px}
  .timeline .meta{color:var(--muted);font-size:12px}

  @media (max-width:1200px){
    .kpis{grid-template-columns:repeat(2, minmax(220px,1fr))}
    .grid-2{grid-template-columns:1fr}
    .grid-3{grid-template-columns:1fr}
  }
  @media (max-width:760px){
    .sidebar{position:static;width:auto;border-right:none}
    main{margin:0;padding:18px}
  }
`;
