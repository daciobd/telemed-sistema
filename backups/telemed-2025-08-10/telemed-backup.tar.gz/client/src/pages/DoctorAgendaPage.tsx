import DoctorAgenda from "@/components/dashboard/DoctorAgenda";
import Layout from "@/components/layout/layout";

export default function DoctorAgendaPage() {
  return (
    <Layout>
      <DoctorAgenda />
    </Layout>
  );
}